from threading import Thread
import bpy

bpy.types.WindowManager.DRS.client.Init()
bpy.types.WindowManager.DRS.client.Connect()
Thread(target=bpy.types.WindowManager.DRS.client.RenderRoutine).start()