import subprocess
import time

subprocess.Popen(['c:\\Program Files\\Blender Foundation\\Blender 3.1\\blender.exe', 'c:\\users\\lemonhead\\documents\\blender\\blend.blend',
                '--python', "C:\\Users\\lemonhead\\Documents\\AAA diploma blender addon\\drs_addon\\testing\\test_run_customer.py"])
time.sleep(3)
subprocess.Popen(['c:\\Program Files (x86)\\Steam\\steamapps\\common\\Blender\\blender.exe',
                '--python', "C:\\Users\\lemonhead\\Documents\\AAA diploma blender addon\\drs_addon\\testing\\test_run_worker.py"])
                