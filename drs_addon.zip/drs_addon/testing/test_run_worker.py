from threading import Thread
import bpy

bpy.types.WindowManager.DRS.client.Init()
bpy.types.WindowManager.DRS.client.Connect(id=2)
Thread(target=bpy.types.WindowManager.DRS.client.WorkerRoutine).start()